export default "DummyImage.png"

